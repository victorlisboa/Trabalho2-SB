# Trabalho2-SB
O trabalho consiste em implementar em IA-32 um calculadora de números de 2 precisões diferentes.
Alunos: Victor Hugo e Luis Henrique

Para compilar faça: make calc32 ou make calc16
